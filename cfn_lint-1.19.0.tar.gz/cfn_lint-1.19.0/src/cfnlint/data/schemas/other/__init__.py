"""
Cfn-lint created JSON Schemas to validation of nested JSON objects
Example: IAM policy statements, Step functions, etc.
"""
